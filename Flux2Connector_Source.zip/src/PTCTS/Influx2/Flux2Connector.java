package PTCTS.Influx2;

import java.time.Instant;
import java.util.List;

import org.slf4j.Logger;

import com.influxdb.client.InfluxDBClient;
import com.influxdb.client.InfluxDBClientFactory;
import com.influxdb.client.QueryApi;
import com.influxdb.client.domain.Bucket;
import com.influxdb.query.FluxRecord;
import com.influxdb.query.FluxTable;

import com.thingworx.data.util.InfoTableInstanceFactory;
import com.thingworx.logging.LogUtilities;
import com.thingworx.metadata.annotations.ThingworxBaseTemplateDefinition;
import com.thingworx.metadata.annotations.ThingworxConfigurationTableDefinition;
import com.thingworx.metadata.annotations.ThingworxConfigurationTableDefinitions;
import com.thingworx.metadata.annotations.ThingworxDataShapeDefinition;
import com.thingworx.metadata.annotations.ThingworxFieldDefinition;
import com.thingworx.metadata.annotations.ThingworxServiceDefinition;
import com.thingworx.metadata.annotations.ThingworxServiceParameter;
import com.thingworx.metadata.annotations.ThingworxServiceResult;
import com.thingworx.system.ContextType;
import com.thingworx.things.Thing;
import com.thingworx.types.InfoTable;
import com.thingworx.types.collections.ValueCollection;
import com.thingworx.types.primitives.StringPrimitive;


@ThingworxBaseTemplateDefinition(name = "GenericThing")
@ThingworxConfigurationTableDefinitions(tables = {
		@ThingworxConfigurationTableDefinition(name = "ConnectionInfo", description = "Influx Connection Info", isMultiRow = false, ordinal = 0, dataShape = @ThingworxDataShapeDefinition(fields = {
				@ThingworxFieldDefinition(name = "InfluxServer", description = "", baseType = "STRING", ordinal = 0),
				@ThingworxFieldDefinition(name = "OrgName", description = "", baseType = "STRING", ordinal = 1),
				@ThingworxFieldDefinition(name = "InfluxToken", description = "", baseType = "STRING", ordinal = 2) })) })

public class Flux2Connector extends Thing {	
	private static Logger _logger = LogUtilities.getInstance().getApplicationLogger(Flux2Connector.class);
	private static final long serialVersionUID = 2L;	

	private String myToken; 
	private String myOrg;
	private String myServer;	
	
	@Override
	protected void  initializeThing(ContextType ex) throws Exception {
		this.myServer=this.getStringConfigurationSetting("ConnectionInfo","InfluxServer");
		this.myToken=this.getStringConfigurationSetting("ConnectionInfo","InfluxToken");
		this.myOrg= this.getStringConfigurationSetting("ConnectionInfo","OrgName");		
	}	

	public Flux2Connector() {
		//
	}

	@ThingworxServiceDefinition(name = "GetBuckets", description = "", category = "", isAllowOverride = true, aspects = {
			"isAsync:false" })
	@ThingworxServiceResult(name = "Result", description = "", baseType = "INFOTABLE", aspects = {
			"isEntityDataShape:true", "dataShape:GenericStringList" })
	public InfoTable GetBuckets() {
		_logger.trace("Entering Service: GetBuckets");
		InfoTable BucketsResult = null;
		try {
			BucketsResult = InfoTableInstanceFactory.createInfoTableFromDataShape("GenericStringList");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
		
        InfluxDBClient influxDBClient = InfluxDBClientFactory.create(this.myServer, this.myToken.toCharArray(), this.myOrg);
        List<Bucket> bucket = influxDBClient.getBucketsApi().findBucketsByOrgName(this.myOrg);        
        
        for(int i=0;i<bucket.size();i++){
           	ValueCollection BucketValues = new ValueCollection();
           	BucketValues.put("item", new StringPrimitive((String) bucket.get(i).getName().toString()));
           	BucketsResult.addRow(BucketValues);        
    	}           
        
        influxDBClient.close();	
		_logger.trace("Exiting Service: GetBuckets");
		return BucketsResult;
	}
	
	@ThingworxServiceDefinition(name = "GetMeasurements", description = "", category = "", isAllowOverride = false, aspects = {
		"isAsync:false" })
	@ThingworxServiceResult(name = "Result", description = "", baseType = "INFOTABLE", aspects = {
		"isEntityDataShape:true", "dataShape:GenericStringList" })
	public InfoTable GetMeasurements(
		@ThingworxServiceParameter(name = "myBucket", description = "", baseType = "STRING") String myBucket) throws Exception {
	_logger.trace("Entering Service: GetMeasurements");
	
	InfoTable MeasurementsResult = InfoTableInstanceFactory.createInfoTableFromDataShape("GenericStringList");		
	
	InfluxDBClient influxDBClient = InfluxDBClientFactory.create(this.myServer, this.myToken.toCharArray(), this.myOrg);  
	        
	String flux="import \"influxdata/influxdb/schema\" schema.measurements(bucket: \""+myBucket+"\")";
	QueryApi queryApi = influxDBClient.getQueryApi();
	
	List<FluxTable> tables = queryApi.query(flux);       
	        
	for (FluxTable fluxTable : tables) {
	    List<FluxRecord> records = fluxTable.getRecords();
	    for (FluxRecord fluxRecord : records) {
	    	ValueCollection MeasurementValues = new ValueCollection();            	
	    	try {
	    	MeasurementValues.put("item",new StringPrimitive(fluxRecord.getValueByKey("_value").toString()));	
			} catch (Exception e) {
				_logger.error("TWX Influx Measurements Error");
			}
			MeasurementsResult.addRow(MeasurementValues);
	    }            
	}
	influxDBClient.close();
	_logger.trace("Exiting Service: GetMeasurements");
	return MeasurementsResult;		
	}
	
	
	@ThingworxServiceDefinition(name = "GetFields", description = "", category = "", isAllowOverride = false, aspects = {
	"isAsync:false" })
	@ThingworxServiceResult(name = "Result", description = "", baseType = "INFOTABLE", aspects = {
	"isEntityDataShape:true", "dataShape:GenericStringList" })
	public InfoTable GetFields(
		@ThingworxServiceParameter(name = "myBucket", description = "", baseType = "STRING") String myBucket,
		@ThingworxServiceParameter(name = "myMeasurement", description = "", baseType = "STRING") String myMeasurement)
		throws Exception {
		_logger.trace("Entering Service: GetFields");
		
		InfoTable FieldsResult = InfoTableInstanceFactory.createInfoTableFromDataShape("GenericStringList");		
		
		InfluxDBClient influxDBClient = InfluxDBClientFactory.create(this.myServer, this.myToken.toCharArray(), this.myOrg);  
		
		String flux="import \"influxdata/influxdb/schema\" schema.measurementFieldKeys(bucket: \""+myBucket+"\", measurement: \""+myMeasurement+"\")";
		
		QueryApi queryApi = influxDBClient.getQueryApi();
		
		List<FluxTable> tables = queryApi.query(flux);       
		
		for (FluxTable fluxTable : tables) {
		List<FluxRecord> records = fluxTable.getRecords();
			for (FluxRecord fluxRecord : records) {
			ValueCollection MeasurementValues = new ValueCollection();
			try {
			MeasurementValues.put("item",new StringPrimitive(fluxRecord.getValueByKey("_value").toString()));	
			} catch (Exception e) {
				_logger.error("TWX Influx Field Error");
			}
			FieldsResult.addRow(MeasurementValues);
			}            
		}
		influxDBClient.close();
		_logger.trace("Exiting Service: GetMeasurements");
		return FieldsResult;		
	}
	
	@ThingworxServiceDefinition(name = "GetFluxData", description = "", category = "", isAllowOverride = true, aspects = {
		"isAsync:false" })
	@ThingworxServiceResult(name = "Result", description = "", baseType = "INFOTABLE", aspects = {
		"isEntityDataShape:true", "dataShape:PTCTS.FluxResult_DS" })
	public InfoTable GetFluxData(
		@ThingworxServiceParameter(name = "myFluxQ", description = "", baseType = "STRING") String myFluxQ) throws Exception {
	_logger.trace("Entering Service: GetFluxData");
	
	InfluxDBClient influxDBClient = InfluxDBClientFactory.create(this.myServer, this.myToken.toCharArray(), this.myOrg);		
	InfoTable FluxResult = InfoTableInstanceFactory.createInfoTableFromDataShape("PTCTS.FluxResult_DS");
	_logger.trace("TWX QL String: "+myFluxQ);					
	
	QueryApi queryApi = influxDBClient.getQueryApi();
	
	List<FluxTable> tables = queryApi.query(myFluxQ);        
	
	for (FluxTable fluxTable : tables) {
	    List<FluxRecord> records = fluxTable.getRecords();
	    for (FluxRecord fluxRecord : records) {
	    	ValueCollection DataValues = new ValueCollection();
	    	try {
	    		Instant FluxTimeStamp=fluxRecord.getTime();	    			    		
	    		DataValues.put("TimeStamp",new StringPrimitive(FluxTimeStamp.toString()));	
			} catch (Exception e) {
				_logger.error("TWX TimeError: "+e);
			}
	    	
	    	try {
	        	DataValues.put("PropertyName",new StringPrimitive(fluxRecord.getField().toString()));	
			} catch (Exception e) {
				_logger.error("TWX PropNameError: "+e);				
			}
	
	    	try {
	        	DataValues.put("PropertyValue",new StringPrimitive(fluxRecord.getValueByKey("_value").toString()));	
			} catch (Exception e) {
				_logger.error("TWX PropValueError: "+e);				
			}            	
	        FluxResult.addRow(DataValues);
	    }            
	}        
	influxDBClient.close(); 
	_logger.warn("Exiting Service: GetFluxData") ;
	return FluxResult;	
	}	

}
